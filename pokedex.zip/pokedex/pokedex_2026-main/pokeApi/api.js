const BASE_URL = "https://pokeapi.co/api/v2";

let getAllPokemons = async (limit = 151) => {
    let pokemonData = await fetch(`${BASE_URL}/pokemon?limit=${limit}&offset=0`);
    if (!pokemonData.ok) throw new Error("No se pudo cargar la Pokédex");
    return await pokemonData.json();
};

let getPokemonById = async (id) => {
    let pokemonData = await fetch(`${BASE_URL}/pokemon/${String(id).trim().toLowerCase()}`);
    if (!pokemonData.ok) throw new Error("Pokémon no encontrado");
    return await pokemonData.json();
};

let getPokemonsAbility = async (abilityName) => {
    let pokemonData = await fetch(`${BASE_URL}/ability/${abilityName}`);
    if (!pokemonData.ok) throw new Error("Habilidad no encontrada");
    return await pokemonData.json();
};

let getPokemonType = async (typeName) => {
    let pokemonData = await fetch(`${BASE_URL}/type/${typeName}`);
    if (!pokemonData.ok) throw new Error("Tipo no encontrado");
    return await pokemonData.json();
};

export { getAllPokemons, getPokemonById, getPokemonsAbility, getPokemonType };
