import * as pokeApi from "./pokeApi/api.js";

const TOTAL = 151;
const PER_PAGE = 8;
let currentId = 25;
let currentPage = 0;
let activeType = "all";
let catalog = [];
let pokemonCache = new Map();

const $ = (id) => document.getElementById(id);

const speciesNames = {
    pikachu: "Ratón", bulbasaur: "Semilla", ivysaur: "Semilla", venusaur: "Semilla",
    charmander: "Lagartija", charmeleon: "Llama", charizard: "Llama", squirtle: "Tortuguita",
    wartortle: "Tortuga", blastoise: "Marisco"
};
const spanishTypes = { normal:"NORMAL", fire:"FUEGO", water:"AGUA", electric:"ELECTRIC", grass:"PLANTA", ice:"HIELO", fighting:"LUCHA", poison:"VENENO", ground:"TIERRA", flying:"VOLADOR", psychic:"PSIQUICO", bug:"BICHO", rock:"ROCA", ghost:"FANTASMA", dragon:"DRAGÓN", dark:"SINIESTRO", steel:"ACERO", fairy:"HADA" };
const typeClasses = { grass:"grass", fire:"fire", water:"water", electric:"electric", psychic:"psychic" };
const statNames = { hp:"PS", attack:"ATAQUE", defense:"DEFENSA", "special-attack":"ATQ. ESP.", "special-defense":"DEF. ESP.", speed:"VELOCIDAD" };

function sprite(id) { return `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/${id}.png`; }
function number(id) { return `#${String(id).padStart(3, "0")}`; }
function prettyName(name) { return name.toUpperCase(); }
function showToast(message) { const t = $("toast"); t.textContent = message; t.classList.add("show"); setTimeout(() => t.classList.remove("show"), 1800); }

async function getPokemon(id) {
    if (pokemonCache.has(id)) return pokemonCache.get(id);
    const data = await pokeApi.getPokemonById(id);
    pokemonCache.set(id, data);
    return data;
}

function drawStats(data) {
    $("stats").innerHTML = data.stats.map(s => {
        const value = s.base_stat;
        const width = Math.min(100, Math.round(value / 1.6));
        return `<div class="stat"><label>${statNames[s.stat.name] || s.stat.name.toUpperCase()}</label><div class="bar"><i style="width:${width}%"></i></div><em>${value}</em></div>`;
    }).join("");
}

async function renderPokemon(id) {
    try {
        id = Math.max(1, Math.min(TOTAL, Number(id)));
        currentId = id;
        const data = await getPokemon(id);
        const types = data.types.map(t => t.type.name);
        const primary = types[0];
        $("pokemonNumber").textContent = number(id);
        $("pokemonName").textContent = prettyName(data.name);
        $("screenId").textContent = `ID: ${number(id)} · ${prettyName(data.name)}`;
        $("pokemonImage").src = data.sprites.other["official-artwork"].front_default || sprite(id);
        $("pokemonImage").alt = data.name;
        $("species").textContent = speciesNames[data.name] || "Pokémon";
        $("height").textContent = `${(data.height / 10).toFixed(1)} m`;
        $("weight").textContent = `${data.weight / 10} kg`;
        $("primaryType").textContent = spanishTypes[primary] || primary.toUpperCase();
        $("primaryType").className = `type-badge ${typeClasses[primary] || "electric"}`;
        $("description").textContent = getDescription(data);
        drawStats(data);
        $("cryAudio").src = data.cries?.latest || data.cries?.legacy || "";
        document.querySelectorAll(".catalog-item").forEach(el => el.classList.toggle("selected", Number(el.dataset.id) === id));
    } catch (error) {
        showToast("No se pudo cargar el Pokémon");
    }
}

function getDescription(data) {
    const known = {
        pikachu: "Levanta su cola para vigilar los alrededores. A veces, puede ser alcanzado por un rayo en esa pose.",
        bulbasaur: "Tiene una semilla plantada en el lomo desde que nace. La semilla crece con él.",
        charmander: "La llama que tiene en la punta de la cola indica su estado físico y emocional.",
        squirtle: "Se protege con su caparazón y dispara agua con gran precisión para atacar a sus rivales."
    };
    return known[data.name] || `Pokémon de tipo ${data.types.map(t => spanishTypes[t.type.name] || t.type.name).join(" / ")}. Forma parte del registro oficial de Kanto.`;
}

function renderQuickNumbers() {
    $("numberGrid").innerHTML = [1,2,3,4,5,6,7,8,9,10].map(n => `<button data-id="${n}">${n}</button>`).join("");
    $("numberGrid").addEventListener("click", e => { if (e.target.dataset.id) renderPokemon(e.target.dataset.id); });
}

async function loadCatalog() {
    try {
        const result = await pokeApi.getAllPokemons(TOTAL);
        catalog = result.results.map((p, i) => ({ id: i + 1, name: p.name }));
        renderCatalog();
    } catch (e) {
        showToast("No se pudo cargar el catálogo");
    }
}

function renderCatalog() {
    const filtered = activeType === "all" ? catalog : catalog.filter(p => {
        const data = pokemonCache.get(p.id);
        return data?.types.some(t => t.type.name === activeType);
    });
    const maxPage = Math.max(0, Math.ceil(filtered.length / PER_PAGE) - 1);
    currentPage = Math.min(currentPage, maxPage);
    const items = filtered.slice(currentPage * PER_PAGE, currentPage * PER_PAGE + PER_PAGE);
    $("catalogGrid").innerHTML = items.map(p => `<div class="catalog-item ${p.id === currentId ? "selected" : ""}" data-id="${p.id}"><img src="${sprite(p.id)}" loading="lazy" alt=""><span><b>${number(p.id)}</b>${prettyName(p.name)}</span></div>`).join("");
    $("pageNumber").textContent = currentPage + 1;
    $("catalogNext").disabled = currentPage >= maxPage;
    $("catalogPrev").disabled = currentPage <= 0;
    $("catalogGrid").onclick = async e => { const item = e.target.closest(".catalog-item"); if (item) await renderPokemon(item.dataset.id); };

    // Cargamos los tipos de los Pokémon visibles para que los filtros funcionen sin bloquear el inicio.
    items.forEach(async p => { try { await getPokemon(p.id); if (activeType !== "all") renderCatalog(); } catch (_) {} });
}

function setupFilters() {
    document.querySelectorAll(".filter").forEach(btn => btn.addEventListener("click", async () => {
        document.querySelectorAll(".filter").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
        activeType = btn.dataset.type;
        currentPage = 0;
        if (activeType !== "all") {
            showToast("Cargando Pokémon del tipo seleccionado...");
            await Promise.all(catalog.map(p => getPokemon(p.id).catch(() => null)));
        }
        renderCatalog();
    }));
}

function setupSearch() {
    $("searchForm").addEventListener("submit", async e => {
        e.preventDefault();
        const value = $("searchInput").value.trim().toLowerCase();
        if (!value) return;
        try {
            const data = await getPokemon(value);
            if (data.id > TOTAL) throw new Error();
            await renderPokemon(data.id);
            $("searchInput").value = "";
        } catch (_) { showToast("Pokémon no encontrado en Kanto"); }
    });
}

function setupNavigation() {
    $("prevBtn").onclick = () => renderPokemon(currentId - 1);
    $("nextBtn").onclick = () => renderPokemon(currentId + 1);
    $("catalogPrev").onclick = () => { if (currentPage > 0) { currentPage--; renderCatalog(); } };
    $("catalogNext").onclick = () => { currentPage++; renderCatalog(); };
    $("infoBtn").onclick = () => showToast("Pokédex Kanto · 151 especies registradas");
    document.querySelector('a[href="#cries"]').onclick = e => { e.preventDefault(); $("cryAudio").play().catch(() => showToast("Selecciona un Pokémon para escuchar su grito")); };
    document.querySelector('a[href="#diagnostico"]').onclick = e => { e.preventDefault(); showToast("Sistema OK · Conexión con PokéAPI activa"); };
}

window.addEventListener("load", async () => {
    renderQuickNumbers();
    setupFilters();
    setupSearch();
    setupNavigation();
    await renderPokemon(currentId);
    await loadCatalog();
});
